# Spring boot chat application
